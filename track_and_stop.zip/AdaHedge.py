import numpy as np
import math
from scipy.special import logsumexp
from environment import BaseEnvironment
class ChernoffStoppingCondition:
    def __init__(self, tol: float = 1e-5):
        # tolerance for floating-point comparisons
        self.tol = tol

    def should_stop(
        self,
        counts: np.ndarray,
        rewards: np.ndarray,
        env,
        confidence: float
    ) -> bool:
        K = counts.size
        t = int(counts.sum())
        if t < K:
            return False

        # choose KL divergence
        if hasattr(env, 'sigma'):
            sigma2 = float(env.sigma) ** 2
            kl = lambda p, q: _kl_gaussian(p, q, sigma2)
        else:
            kl = _kl_bernoulli

        # empirical means
        mu_hat = rewards / counts
        # find empirical best arms within tolerance
        max_mu = mu_hat.max()
        best_arms = [i for i in range(K) if mu_hat[i] >= max_mu - self.tol]
        best = int(np.random.choice(best_arms))

        # compute Chernoff statistic only for the empirical best
        NB = counts[best]
        SB = rewards[best]
        muB = SB / NB
        worst = math.inf
        for i in range(K):
            if i == best:
                continue
            n_ab = NB + counts[i]
            mix = (NB * muB + counts[i] * mu_hat[i]) / n_ab
            val = NB * kl(muB, mix) + counts[i] * kl(mu_hat[i], mix)
            worst = min(worst, val)

        beta = math.log((math.log(t) + 1) / confidence)
        # print("Worst: ", worst, " beta: ", beta)
        return worst > beta
# KL divergences
def _kl_bernoulli(p: float, q: float) -> float:
    p = np.clip(p, 1e-3, 1 - 1e-3)
    q = np.clip(q, 1e-3, 1 - 1e-3)
    return p * np.log(p / q) + (1 - p) * np.log((1 - p) / (1 - q))

def _kl_gaussian(p: float, q: float, sigma2: float = 1.0) -> float:
    return (p - q) ** 2 / (2.0 * sigma2)

# KL-based confidence interval by bisection
def kl_interval(mu_hat, N, f_t, kl, lower_bound, upper_bound, tol=1e-7):
    """Finds [alpha, beta] s.t. N * kl(mu_hat, alpha) = f_t and same for beta."""
    # alpha: search in [lower_bound, mu_hat]
    lo, hi = lower_bound, mu_hat
    target = f_t / N
    while hi - lo > tol:
        mid = (lo + hi) / 2

        if N * kl(mu_hat, mid) < f_t:
            hi = mid
        else:
            lo = mid
    alpha = lo
    # beta: search in [mu_hat, upper_bound]

    lo, hi = mu_hat, upper_bound
    while hi - lo > tol:
        mid = (lo + hi) / 2
        if N * kl(mu_hat, mid) < f_t:
            lo = mid
        else:
            hi = mid
    beta = hi
    #print(mu_hat, N, f_t)
    return alpha, beta

# AdaHedge for the k-player
class AdaHedge:
    def __init__(self, K: int):
        self.K = K
        self.L = np.zeros(K)           # cumulative losses
        self.Delta = math.log(K)       # mixability gap initial

    def probs(self):
        eta = math.log(self.K) / self.Delta
        weights = np.exp(-eta * self.L)
        return weights / weights.sum()

    def update(self, losses: np.ndarray):
        eta = math.log(self.K) / self.Delta
        old_logsum = logsumexp(-eta * self.L)
        self.L += losses
        new_logsum = logsumexp(-eta * self.L)
        self.Delta += new_logsum - old_logsum

# Best-response oracle for Bernoulli or Gaussian best-arm
def best_response(w: np.ndarray, mu_hat: np.ndarray, i: int, kl, gaussian=False, sigma2=1.0):
    K = len(w)
    best_val = math.inf
    best_lambda = None
    # Only pairs (i, j) matter
    for j in range(K):
        if j == i:
            continue
        # Solve for theta* minimizing w[i]*d(mu_hat[i], theta) + w[j]*d(mu_hat[j], theta)
        if gaussian:
            # analytic minimizer for gaussian: weighted average
            theta_star = (w[i] * mu_hat[i] + w[j] * mu_hat[j]) / (w[i] + w[j])
        else:
            # bisection in [0,1]
            def obj(theta):
                return w[i] * kl(mu_hat[i], theta) + w[j] * kl(mu_hat[j], theta)
            lo, hi = 0.0, 1.0
            for _ in range(20):
                m1 = lo + (hi - lo) / 3
                m2 = hi - (hi - lo) / 3
                if obj(m1) < obj(m2):
                    hi = m2
                else:
                    lo = m1
            theta_star = (lo + hi) / 2
        val = w[i] * kl(mu_hat[i], theta_star) + w[j] * kl(mu_hat[j], theta_star)
        if val < best_val:
            best_val = val
            lam = mu_hat.copy()
            lam[i] = lam[j] = theta_star
            best_lambda = lam
    return best_lambda

# Main D algorithm (AdaHedge vs Best-Response, direct tracking)
def run_D(env: BaseEnvironment, delta: float):
    K = env.num_arms
    counts = np.zeros(K, dtype=int)
    rewards = np.zeros(K)
    # initial pulls
    for k in range(K):
        x = env.sample(k)
        counts[k] += 1
        rewards[k] += x

    ada = AdaHedge(K)
    t = K

    # choose KL function
    if hasattr(env, 'sigma'):
        gaussian = True
        sigma2 = env.sigma ** 2
        kl = lambda p, q: _kl_gaussian(p, q, sigma2)
    else:
        gaussian = False
        kl = _kl_bernoulli

    while True:
        mu_hat = rewards / counts
        # compute intervals
        f_t = math.log(t)
        intervals = [kl_interval(mu_hat[k], counts[k], f_t, kl,
                                 0.0 if not gaussian else mu_hat[k]-5*env.sigma,
                                 1.0 if not gaussian else mu_hat[k]+5*env.sigma)
                     for k in range(K)]
        #print(intervals)
        # candidate best-arm
        i_t = int(np.argmax(mu_hat))
        # stopping check
        if ChernoffStoppingCondition().should_stop(counts, rewards, env, delta):
            return i_t, t

        # AdaHedge distribution
        w_t = ada.probs()
        # best-response lambda
        lambda_t = best_response(w_t, mu_hat, i_t, kl, gaussian, sigma2 if gaussian else None)
        # optimistic payoffs
        U = np.zeros(K)
        for k in range(K):
            alpha_k, beta_k = intervals[k]
            bonus = f_t / counts[k]
            # worst-case at endpoints
            u_end = max(kl(alpha_k, lambda_t[k]), kl(beta_k, lambda_t[k]))
            U[k] = max(bonus, u_end)
        # update AdaHedge
        losses = -U
        ada.update(losses)
        # direct tracking
        k_t = int(np.argmax(w_t))
        #print(k_t)
        x = env.sample(k_t)
        counts[k_t] += 1
        rewards[k_t] += x
        t += 1

# Example usage
if __name__ == "__main__":
    from environment import BernoulliEnvironment, NormalEnvironment
    # Bernoulli test
    k = 0
    for i in range(300):

        env = BernoulliEnvironment(num_arms=4, env_type="best_gap")
        winner, pulls = run_D(env, delta=0.1)
        k = k + pulls
        print(f"Bernoulli identified arm {winner} in {pulls} pulls.", k/(i+1), i+1)


    # Normal test
    env = NormalEnvironment(num_arms=5, env_type="competition", sigma=1.0)
    winner, pulls = run_D(env, delta=0.1)
    print(f"Normal identified arm {winner} in {pulls} pulls.")
